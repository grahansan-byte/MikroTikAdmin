# Keep rules for MikroTik Admin WebFig wrapper
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
