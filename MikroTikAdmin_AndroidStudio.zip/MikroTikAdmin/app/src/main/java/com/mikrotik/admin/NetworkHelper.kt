package com.mikrotik.admin

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import java.net.Inet4Address

object NetworkHelper {

    fun isWifiConnected(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    /**
     * Detects the current Wi-Fi router (Gateway) IPv4 address using LinkProperties,
     * with a fallback to WifiManager.dhcpInfo for older devices.
     */
    @Suppress("DEPRECATION")
    fun detectWifiGatewayIp(context: Context): String? {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = cm.activeNetwork
        if (activeNetwork != null) {
            val capabilities = cm.getNetworkCapabilities(activeNetwork)
            if (capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
                val linkProperties = cm.getLinkProperties(activeNetwork)
                val gateway = linkProperties?.routes
                    ?.firstOrNull { route ->
                        route.isDefaultRoute && route.gateway is Inet4Address
                    }
                    ?.gateway
                    ?.hostAddress
                if (!gateway.isNullOrBlank() && gateway != "0.0.0.0") {
                    return gateway
                }
            }
        }

        // Fallback via WifiManager
        return try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val gatewayInt = wifiManager.dhcpInfo?.gateway ?: 0
            if (gatewayInt == 0) {
                null
            } else {
                String.format(
                    "%d.%d.%d.%d",
                    gatewayInt and 0xff,
                    gatewayInt shr 8 and 0xff,
                    gatewayInt shr 16 and 0xff,
                    gatewayInt shr 24 and 0xff
                )
            }
        } catch (_: Exception) {
            null
        }
    }
}
