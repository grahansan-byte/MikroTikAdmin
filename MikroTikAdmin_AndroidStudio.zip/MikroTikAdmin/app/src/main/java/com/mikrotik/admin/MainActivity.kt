package com.mikrotik.admin

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import com.mikrotik.admin.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsManager
    private var currentTargetUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsManager(this)
        setupWebView()
        setupControls()
        setupBackNavigation()

        connectToMikroTik()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        val settings = webView.settings

        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.loadsImagesAutomatically = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                binding.progressBar.progress = newProgress
                binding.progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                binding.errorLayout.visibility = View.GONE
                binding.webView.visibility = View.VISIBLE
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    showErrorState(
                        getString(R.string.error_unreachable_title),
                        getString(R.string.error_unreachable_desc, currentTargetUrl ?: "")
                    )
                }
            }

            override fun onReceivedSslError(
                view: WebView?,
                handler: SslErrorHandler?,
                error: SslError?
            ) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.ssl_dialog_title)
                    .setMessage(R.string.ssl_dialog_message)
                    .setPositiveButton(R.string.ssl_continue) { _, _ -> handler?.proceed() }
                    .setNegativeButton(R.string.cancel) { _, _ -> handler?.cancel() }
                    .show()
            }
        }

        // Support downloading .backup or .rsc files from MikroTik WebFig
        webView.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                val fileName = URLUtil.guessFileName(url, contentDisposition, mimetype)
                request.setMimeType(mimetype)
                request.addRequestHeader("User-Agent", userAgent)
                val cookies = CookieManager.getInstance().getCookie(url)
                if (!cookies.isNullOrEmpty()) {
                    request.addRequestHeader("Cookie", cookies)
                }
                request.setTitle(fileName)
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                Toast.makeText(this, getString(R.string.download_started, fileName), Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(this, R.string.download_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupControls() {
        binding.btnRefresh.setOnClickListener {
            connectToMikroTik()
        }

        binding.btnSettings.setOnClickListener {
            showIpSettingsDialog()
        }

        binding.btnRetry.setOnClickListener {
            connectToMikroTik()
        }

        binding.btnChangeIp.setOnClickListener {
            showIpSettingsDialog()
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun connectToMikroTik() {
        val targetHost: String?
        val modeLabel: String

        if (prefs.useAutoGateway) {
            if (!NetworkHelper.isWifiConnected(this)) {
                binding.tvStatus.text = getString(R.string.status_no_wifi)
                showErrorState(
                    getString(R.string.error_no_wifi_title),
                    getString(R.string.error_no_wifi_desc)
                )
                return
            }
            targetHost = NetworkHelper.detectWifiGatewayIp(this)
            modeLabel = getString(R.string.mode_auto_short)
            if (targetHost.isNullOrBlank()) {
                binding.tvStatus.text = getString(R.string.status_gateway_not_found)
                showErrorState(
                    getString(R.string.error_no_gateway_title),
                    getString(R.string.error_no_gateway_desc)
                )
                return
            }
        } else {
            targetHost = prefs.manualIp
            modeLabel = getString(R.string.mode_manual_short)
            if (targetHost.isBlank()) {
                showIpSettingsDialog()
                return
            }
        }

        val url = prefs.buildTargetUrl(targetHost)
        currentTargetUrl = url
        binding.tvStatus.text = "$modeLabel • $targetHost"
        binding.errorLayout.visibility = View.GONE
        binding.webView.visibility = View.VISIBLE
        binding.webView.loadUrl(url)
    }

    private fun showErrorState(title: String, description: String) {
        binding.webView.visibility = View.GONE
        binding.errorLayout.visibility = View.VISIBLE
        binding.tvErrorTitle.text = title
        binding.tvErrorDesc.text = description
    }

    private fun showIpSettingsDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_ip_settings, null)
        val radioGroup = dialogView.findViewById<RadioGroup>(R.id.rgMode)
        val rbAuto = dialogView.findViewById<RadioButton>(R.id.rbAuto)
        val rbManual = dialogView.findViewById<RadioButton>(R.id.rbManual)
        val etIp = dialogView.findViewById<EditText>(R.id.etIpAddress)
        val etPort = dialogView.findViewById<EditText>(R.id.etPort)
        val switchHttps = dialogView.findViewById<SwitchMaterial>(R.id.switchHttps)

        etIp.setText(prefs.manualIp)
        etPort.setText(prefs.port)
        switchHttps.isChecked = prefs.useHttps

        if (prefs.useAutoGateway) {
            rbAuto.isChecked = true
            etIp.isEnabled = false
        } else {
            rbManual.isChecked = true
            etIp.isEnabled = true
        }

        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            etIp.isEnabled = checkedId == R.id.rbManual
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.settings_dialog_title)
            .setView(dialogView)
            .setPositiveButton(R.string.save_and_connect) { _, _ ->
                val isAuto = rbAuto.isChecked
                val enteredIp = etIp.text.toString().trim()
                val enteredPort = etPort.text.toString().trim()

                if (!isAuto && enteredIp.isEmpty()) {
                    Toast.makeText(this, R.string.error_empty_ip, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                prefs.useAutoGateway = isAuto
                if (enteredIp.isNotEmpty()) {
                    prefs.manualIp = enteredIp
                }
                prefs.port = if (enteredPort.isEmpty()) PrefsManager.DEFAULT_PORT else enteredPort
                prefs.useHttps = switchHttps.isChecked

                connectToMikroTik()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
