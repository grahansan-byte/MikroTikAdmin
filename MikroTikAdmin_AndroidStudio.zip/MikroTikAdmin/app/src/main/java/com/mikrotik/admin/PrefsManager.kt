package com.mikrotik.admin

import android.content.Context

class PrefsManager(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var useAutoGateway: Boolean
        get() = prefs.getBoolean(KEY_AUTO_GATEWAY, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_GATEWAY, value).apply()

    var manualIp: String
        get() = prefs.getString(KEY_MANUAL_IP, DEFAULT_IP) ?: DEFAULT_IP
        set(value) = prefs.edit().putString(KEY_MANUAL_IP, value.trim()).apply()

    var port: String
        get() = prefs.getString(KEY_PORT, DEFAULT_PORT) ?: DEFAULT_PORT
        set(value) = prefs.edit().putString(KEY_PORT, value.trim()).apply()

    var useHttps: Boolean
        get() = prefs.getBoolean(KEY_USE_HTTPS, false)
        set(value) = prefs.edit().putBoolean(KEY_USE_HTTPS, value).apply()

    fun buildTargetUrl(hostIp: String): String {
        val cleanHost = hostIp
            .trim()
            .removePrefix("http://")
            .removePrefix("https://")
            .trimEnd('/')
        val scheme = if (useHttps) "https" else "http"
        val cleanPort = port.trim()
        val includePort = cleanPort.isNotEmpty() &&
            !((!useHttps && cleanPort == "80") || (useHttps && cleanPort == "443")) &&
            !cleanHost.contains(":")

        return if (includePort) {
            "$scheme://$cleanHost:$cleanPort/"
        } else {
            "$scheme://$cleanHost/"
        }
    }

    companion object {
        private const val PREFS_NAME = "mikrotik_admin_prefs"
        private const val KEY_AUTO_GATEWAY = "auto_gateway"
        private const val KEY_MANUAL_IP = "manual_ip"
        private const val KEY_PORT = "port"
        private const val KEY_USE_HTTPS = "use_https"
        const val DEFAULT_IP = "192.168.88.1"
        const val DEFAULT_PORT = "80"
    }
}
